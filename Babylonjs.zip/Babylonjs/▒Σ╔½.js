/*-------------------------- * YuanZhuiPoSuiJi变色 * -------------------------- */
// 黑色
M_YuanZhuiPoSuiJi_Paint_Main.albedoColor = new BABYLON.Color3(0.07058823529411765, 0.07058823529411765, 0.07058823529411765);
M_YuanZhuiPoSuiJi_Paint_Main.metallic = 1;
M_YuanZhuiPoSuiJi_Paint_Main.roughness = 0.2;
M_YuanZhuiPoSuiJi_Paint_Main.bumpTexture.level = 0.02;

M_YuanZhuiPoSuiJi_Metal_Steel_Silver.albedoColor = new BABYLON.Color3(0.41568627450980394, 0.28627450980392155, 0.00392156862745098);
M_YuanZhuiPoSuiJi_Metal_Steel_Silver.roughness = 0.26;

M_YuanZhuiPoSuiJi_Paint_Less.albedoColor = new BABYLON.Color3(0.34901960784313724, 0.34901960784313724, 0.34901960784313724);
M_YuanZhuiPoSuiJi_Paint_Less.metallic = 0;
M_YuanZhuiPoSuiJi_Paint_Less.roughness = 0.35;
M_YuanZhuiPoSuiJi_Paint_Less.metallicF0Factor = 0.62;
M_YuanZhuiPoSuiJi_Paint_Less.bumpTexture.level = 0.15;

M_YuanZhuiPoSuiJi_Logo_Texture.albedoColor = new BABYLON.Color3(0.4392156862745098, 0.4392156862745098, 0.4392156862745098);
M_YuanZhuiPoSuiJi_Logo_Texture.roughness = 0.14;

// 蓝色

M_YuanZhuiPoSuiJi_Paint_Main.albedoColor = new BABYLON.Color3(0.00784313725490196, 0.047058823529411764, 0.11372549019607843);
M_YuanZhuiPoSuiJi_Paint_Main.bumpTexture.level = 0.5;
M_YuanZhuiPoSuiJi_Paint_Main.metallic = 0.27;
M_YuanZhuiPoSuiJi_Paint_Main.roughness = 0.19;

M_YuanZhuiPoSuiJi_Metal_Steel_Silver.albedoColor = new BABYLON.Color3(0.1803921568627451, 0.1803921568627451, 0.1803921568627451);
M_YuanZhuiPoSuiJi_Metal_Steel_Silver.roughness = 0.18;

M_YuanZhuiPoSuiJi_Paint_Less.albedoColor = new BABYLON.Color3(0.09803921568627451, 0, 0);
M_YuanZhuiPoSuiJi_Paint_Less.metallic = 0;
M_YuanZhuiPoSuiJi_Paint_Less.roughness = 0.35;
M_YuanZhuiPoSuiJi_Paint_Less.metallicF0Factor = 0.62;
M_YuanZhuiPoSuiJi_Paint_Less.bumpTexture.level = 0.15;

M_YuanZhuiPoSuiJi_Logo_Texture.albedoColor = new BABYLON.Color3(0.4392156862745098, 0.4392156862745098, 0.4392156862745098);
M_YuanZhuiPoSuiJi_Logo_Texture.roughness = 0.14;

//黄色
M_YuanZhuiPoSuiJi_Paint_Main.albedoColor = new BABYLON.Color3(0.36470588235294116, 0.18823529411764706, 0);
M_YuanZhuiPoSuiJi_Paint_Main.bumpTexture.level = 0.45;
M_YuanZhuiPoSuiJi_Paint_Main.metallic = 0.2;
M_YuanZhuiPoSuiJi_Paint_Main.roughness = 0.14;

M_YuanZhuiPoSuiJi_Metal_Steel_Silver.metallic = 1;
M_YuanZhuiPoSuiJi_Metal_Steel_Silver.roughness = 0.05;

M_YuanZhuiPoSuiJi_Paint_Less.albedoColor = new BABYLON.Color3(0.23921568627450981, 0.23921568627450981, 0.23921568627450981);
M_YuanZhuiPoSuiJi_Paint_Less.metallic = 1;
M_YuanZhuiPoSuiJi_Paint_Less.roughness = 0.05;
M_YuanZhuiPoSuiJi_Paint_Less.metallicF0Factor = 0.5;
M_YuanZhuiPoSuiJi_Paint_Less.bumpTexture.level = 0.15;

M_YuanZhuiPoSuiJi_Logo_Texture.albedoColor = new BABYLON.Color3(0.07058823529411765, 0.07058823529411765, 0.07058823529411765);
M_YuanZhuiPoSuiJi_Logo_Texture.roughness = 0.5;


/*-------------------------- * XuanHuiPoSuiJi_变色 * -------------------------- */

// 黑色
M_XuanHuiPoSuiJi_Paint_Main.albedoColor = new BABYLON.Color3(0.07058823529411765, 0.07058823529411765, 0.07058823529411765);
M_XuanHuiPoSuiJi_Paint_Main.metallic = 1;
M_XuanHuiPoSuiJi_Paint_Main.roughness = 0.2;
M_XuanHuiPoSuiJi_Paint_Main.bumpTexture.level = 0.02;

M_XuanHuiPoSuiJi_AN_Screw_Steel.albedoColor = new BABYLON.Color3(0.1411764705882353, 0.09411764705882353, 0);
M_XuanHuiPoSuiJi_AN_Screw_Steel.roughness = 0.24;

M_XuanHuiPoSuiJi_Screw_Steel.albedoColor = new BABYLON.Color3(0.1411764705882353, 0.09411764705882353, 0);
M_XuanHuiPoSuiJi_Screw_Steel.roughness = 0.24;


// 蓝色
M_XuanHuiPoSuiJi_Paint_Main.albedoColor = new BABYLON.Color3(0.00784313725490196, 0.047058823529411764, 0.11372549019607843);
M_XuanHuiPoSuiJi_Paint_Main.bumpTexture.level = 0.5;
M_XuanHuiPoSuiJi_Paint_Main.metallic = 0.27;
M_XuanHuiPoSuiJi_Paint_Main.roughness = 0.19;

M_XuanHuiPoSuiJi_AN_Screw_Steel.albedoColor = new BABYLON.Color3(0.03, 0.03, 0.03);
M_XuanHuiPoSuiJi_AN_Screw_Steel.roughness = 0.24;

M_XuanHuiPoSuiJi_Screw_Steel.albedoColor = new BABYLON.Color3(0.03, 0.03, 0.03);
M_XuanHuiPoSuiJi_Screw_Steel.roughness = 0.24;

//黄色
M_XuanHuiPoSuiJi_Paint_Main.albedoColor = new BABYLON.Color3(0.36470588235294116, 0.18823529411764706, 0);
M_XuanHuiPoSuiJi_Paint_Main.bumpTexture.level = 0.45;
M_XuanHuiPoSuiJi_Paint_Main.metallic = 0.2;
M_XuanHuiPoSuiJi_Paint_Main.roughness = 0.14;

M_XuanHuiPoSuiJi_AN_Screw_Steel.albedoColor = new BABYLON.Color3(0.03, 0.03, 0.03);
M_XuanHuiPoSuiJi_AN_Screw_Steel.roughness = 0.24;

M_XuanHuiPoSuiJi_Screw_Steel.albedoColor = new BABYLON.Color3(0.03, 0.03, 0.03);
M_XuanHuiPoSuiJi_Screw_Steel.roughness = 0.24;



/*-------------------------- * ZhiShaJi_变色 * -------------------------- */
// 黑色
M_Paint_Main.albedoColor = new BABYLON.Color3(0.07058823529411765, 0.07058823529411765, 0.07058823529411765);
M_Paint_Main.metallic = 1;
M_Paint_Main.roughness = 0.2;
M_Paint_Main.bumpTexture.level = 0.02;

M_Paint_Less.albedoColor = new BABYLON.Color3(0.34901960784313724, 0.34901960784313724, 0.34901960784313724);
M_Paint_Less.metallic = 0;
M_Paint_Less.roughness = 0.35;
M_Paint_Less.metallicF0Factor = 0.62;
M_Paint_Less.bumpTexture.level = 0.15;

// 蓝色
M_Paint_Main.albedoColor = new BABYLON.Color3(0.00784313725490196, 0.047058823529411764, 0.11372549019607843);
M_Paint_Main.bumpTexture.level = 0.5;
M_Paint_Main.metallic = 0.27;
M_Paint_Main.roughness = 0.19;


M_Paint_Less.albedoColor = new BABYLON.Color3(0.09803921568627451, 0, 0);
M_Paint_Less.metallic = 0;
M_Paint_Less.roughness = 0.35;
M_Paint_Less.metallicF0Factor = 0.62;
M_Paint_Less.bumpTexture.level = 0.15;


//黄色
M_Paint_Main.albedoColor = new BABYLON.Color3(0.36470588235294116, 0.18823529411764706, 0);
M_Paint_Main.bumpTexture.level = 0.45;
M_Paint_Main.metallic = 0.2;
M_Paint_Main.roughness = 0.14;

M_Paint_Less.albedoColor = new BABYLON.Color3(0.23921568627450981, 0.23921568627450981, 0.23921568627450981);
M_Paint_Less.metallic = 1;
M_Paint_Less.roughness = 0.05;
M_Paint_Less.metallicF0Factor = 0.5;
M_Paint_Less.bumpTexture.level = 0.15;