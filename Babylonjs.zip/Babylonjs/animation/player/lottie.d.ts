import { default as Lottie } from '../../index';

export * from '../../index';

export default Lottie;
